create definer = root@localhost trigger cad_sucursal_AFTER_INSERT
  after INSERT
  on cad_sucursal
  for each row
BEGIN

END;

