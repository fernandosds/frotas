create definer = root@localhost trigger bco_itau_AFTER_INSERT
  after INSERT
  on bco_itau
  for each row
BEGIN

declare vcodfavorec integer;
declare ncodfavorec integer;
declare ncnpjcpf varchar(20);
declare nlat varchar(25);
declare nlon varchar(25);
declare ncodcliente integer;
declare ncia integer;
declare nmodelo varchar(30);
declare nplaca varchar(7);
declare ncontrato integer;
declare nfrota varchar(1);
declare vfrota integer;
declare ntipoveic varchar(20);
declare nsolic varchar(1);
declare ncod_suc integer;
declare nsucursal varchar(50);
declare ndistancia integer;
declare ncod_posto integer;
declare nnomeposto varchar(80);
declare nlat_posto varchar(25);
declare nlon_posto varchar(25);
declare nobs_posto varchar(500);
declare chk_veiculo integer;
declare nbaseativa varchar(20);
declare ninstal datetime;
declare ntp_solic varchar(25);
declare ndata_rec date;
declare atualizado varchar(1);
declare nnovo integer;
declare nassist varchar(1);

declare tecnico_nome_tec varchar(255);
declare tecnico_endereco varchar(255);
declare tecnico_numero varchar(100);
declare tecnico_bairro varchar(255);
declare tecnico_cidade varchar(255);
declare tecnico_estado varchar(2);
declare tecnico_complemento varchar(255);
declare tecnico_cep varchar(9);

INSERT INTO solicitacao (PLACA,CHASSIS,CONTRATO,COD_CLIENTE,APOLICE,TP_SOLICITACAO,SOLICITADO,DATA,
BAIXA,EQUIPTO,BAIXA_FINANCEIRO,OBS,NOME_CLIENTE,USUARIO_ABERTURA,APROVADO,DATA_LIMITE,USUARIO_MANUTENCAO,
COD_OPER,TECNICO,COD_SUCURSAL,SUCURSAL,CORRETOR,OBS_POSTO,EMPRESA,EMAIL_CORRETOR)
values(nplaca,new.chassi,ncontrato,ncodfavorec,new.apolice,'Retirada','C',curdate(),'N','Sat Light',
'N',concat('Corretor:',new.nome_corretor,' Telef.:(',new.ddd_corretor,') ',new.tel_corretor,' Dados de envio/recebimento:',substring(new.dt_registro,7,2),
'/',substring(new.dt_registro,5,2),'/',substring(new.dt_registro,1,4),' Protocolo:',new.contador,' Registro:',
new.registro,' Seguradora:',new.seguradora),new.nome,concat('ADMIN - ',curdate()),'S',concat(substring(new.DATA_LIMITE_AGENDAMENTO,1,4),'-',
substring(new.DATA_LIMITE_AGENDAMENTO,5,2),'-',substring(new.DATA_LIMITE_AGENDAMENTO,7,2)),concat('PA',substring(new.dt_registro,7,2),'/',
substring(new.dt_registro,5,2),'/',substring(new.dt_registro,1,4)),1,nnomeposto,ncod_suc,nsucursal,new.NOME_CORRETOR,nobs_posto,
new.cod_empresa,new.EMAIL_CORRETOR);

if( new.cod_empresa = 37 and new.instalador != 'Sat Company' ) then
	update solicitacao set solicitado = 'I', backoffice = 'S', data = now() where chassis = new.CHASSI and baixa = 'N';
    
    SELECT f.nome as nome_tec, e.endereco, e.numero, e.bairro, e.cidade, e.estado, e.complemento, e.cep
	FROM fv_favor f 
	left join fv_end e on e.CODFAVOREC = f.CODFAVOREC
	WHERE f.codfavorec = new.instalador limit 1
    INTO tecnico_nome_tec, tecnico_endereco, tecnico_numero, tecnico_bairro, tecnico_cidade, tecnico_estado, tecnico_complemento, tecnico_cep;
	
	INSERT INTO agenda_instalador (cod_oper,nome_oper,DATA,status,DATAcontato,horario,nome,cod_cliente,placa,chassis,apolice,
		hor_01,hor_02,dia_semana,nome_inst,cia,status_dev,data_agendamento,cod_inst,periodo) values (
        1,'ADMIN',NOW(),'A',NOW(),date_format(now(),'%H:%m:%s'),new.nome,ncodfavorec,nplaca,new.chassi,new.apolice,
		'08:00','12:00','Segunda-Feira',tecnico_nome_tec,37,'03',NOW(),new.instalador,'M');
        
     INSERT INTO agenda_cliente (data,dia_semana,assunto,status,cod_cliente,horario,datacontato,nome,cod_oper,nome_oper,placa,chassis,
		apolice,status_dev,cia,hor_final,contato,ddd_contato,telefone_contato,ddd_celular,celular_contato) VALUES (
        NOW(),'Segunda-Feira','Agendamento realizada pelo posto revendedor','F',ncodfavorec,date_format(now(),'%H:%m:%s'),now(),
        new.nome,1,'ADMIN',nplaca,new.chassi,new.apolice,'03',37,'12:00',new.nome,new.ddd1,new.telefone1,new.ddd2,new.telefone2);

    INSERT INTO OS (cod_cliente,cod_fav,dispositivo,placa,operacao,operacao_os,data_os,data_inclusao,
		deslocamento,nomecli,cod_tecnico,nometec,Baixa,resa,chassis,apolice,agenda_cliente,
		num,end,compl,bairro,cid,cep,uf,agendamento,distancia,local_inst,obs,qtde_equipamento,
		operador_in,cod_operador,ddd,celular,periodo,Local)
	VALUES (ncodfavorec,0,'',nplaca,1,'Instalação',now(),now(),'N',new.nome,new.instalador,tecnico_nome_tec,'N','N',new.chassi,new.apolice,0,
    tecnico_numero,tecnico_endereco,tecnico_complemento,tecnico_bairro,tecnico_cidade,tecnico_cep,tecnico_estado,
    'Agendamento e Instalação realizada pelo posto-revendedor',0,'P','',1,'ADMIN',1,new.ddd1,new.telefone1,date_format(now(),'%H:%m'),
    CONCAT(tecnico_endereco, ' - ',tecnico_numero, ' - ', tecnico_bairro, ', ', tecnico_cidade, ' - ',tecnico_estado));
        
end if;

END;

